-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 13, 2019 at 11:13 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `snomedct_full`
--

-- --------------------------------------------------------

--
-- Table structure for table `concepts_core`
--

CREATE TABLE IF NOT EXISTS `concepts_core` (
  `CONCEPTID` bigint(20) UNSIGNED DEFAULT NULL,
  `CONCEPTSTATUS` tinyint(3) UNSIGNED DEFAULT NULL,
  `FULLYSPECIFIEDNAME` varchar(500) DEFAULT NULL,
  `CTV3ID` varchar(30) DEFAULT NULL,
  `SNOMEDID` varchar(30) DEFAULT NULL,
  `ISPRIMITIVE` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `map`
--

CREATE TABLE IF NOT EXISTS `map` (
  `id` varchar(200) DEFAULT NULL,
  `effective_time` varchar(8) DEFAULT NULL,
  `active` tinyint(4) DEFAULT NULL,
  `moduleID` bigint(20) DEFAULT NULL,
  `refsetID` bigint(20) DEFAULT NULL,
  `referenceComponentID` bigint(20) DEFAULT NULL,
  `mapGroup` tinyint(4) DEFAULT NULL,
  `mapPriority` tinyint(4) DEFAULT NULL,
  `mapRule` text DEFAULT NULL,
  `mapAdvice` text DEFAULT NULL,
  `mapTarget` varchar(20) DEFAULT NULL,
  `correlationId` bigint(20) DEFAULT NULL,
  `mapCategoryId` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='The map between SNOMED CT and ICD-10';

-- --------------------------------------------------------

--
-- Table structure for table `relationships_core`
--

CREATE TABLE IF NOT EXISTS `relationships_core` (
  `RELATIONSHIPID` bigint(20) DEFAULT NULL,
  `CONCEPTID1` bigint(20) DEFAULT NULL,
  `RELATIONSHIPTYPE` int(11) DEFAULT NULL,
  `CONCEPTID2` bigint(20) DEFAULT NULL,
  `CHARACTERISTICTYPE` tinyint(4) DEFAULT NULL,
  `REFINABILITY` tinyint(4) DEFAULT NULL,
  `RELATIONSHIPGROUP` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rf1_descriptions`
--

CREATE TABLE IF NOT EXISTS `rf1_descriptions` (
  `DESCRIPTIONID` bigint(20) DEFAULT NULL,
  `DESCRIPTIONSTATUS` tinyint(4) DEFAULT NULL,
  `CONCEPTID` bigint(20) DEFAULT NULL,
  `TERM` varchar(200) DEFAULT NULL,
  `INITIALCAPITALSTATUS` tinyint(4) DEFAULT NULL,
  `DESCRIPTIONTYPE` tinyint(4) DEFAULT NULL,
  `LANGUAGECODE` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sct_transitiveclosure`
--

CREATE TABLE IF NOT EXISTS `sct_transitiveclosure` (
  `SubTypeID` bigint(20) DEFAULT NULL,
  `SuperTypeID` bigint(20) DEFAULT NULL,
  KEY `sub_index` (`SubTypeID`),
  KEY `super_index` (`SuperTypeID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
