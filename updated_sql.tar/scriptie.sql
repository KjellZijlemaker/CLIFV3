-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 13, 2019 at 11:12 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scriptie`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `commentid` int(11) NOT NULL AUTO_INCREMENT,
  `indicatorid` int(11) DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `step` varchar(11) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `inserted` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`commentid`),
  UNIQUE KEY `combined_key` (`userid`,`indicatorid`,`step`),
  KEY `indicatorid` (`indicatorid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `concept`
--

CREATE TABLE IF NOT EXISTS `concept` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  `indicatortext` varchar(200) NOT NULL,
  `conceptid` varchar(50) NOT NULL,
  `inserted` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `indicatorid` (`indicatorid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `formalised_constraint`
--

CREATE TABLE IF NOT EXISTS `formalised_constraint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  `constrainttype` varchar(200) DEFAULT NULL,
  `indicatortext` varchar(500) DEFAULT NULL,
  `table` varchar(200) DEFAULT NULL,
  `attribute` varchar(200) DEFAULT NULL,
  `conceptid` varchar(50) DEFAULT NULL,
  `relation` varchar(40) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `table2` varchar(200) DEFAULT NULL,
  `attribute2` varchar(200) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `txt` varchar(50) DEFAULT NULL,
  `boolean` tinyint(1) DEFAULT NULL,
  `isexclusion` tinyint(1) DEFAULT 0,
  `numeratoronly` tinyint(1) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `lastvalue` tinyint(1) NOT NULL DEFAULT 0,
  `inserted` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `indicatorid` (`indicatorid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `indicator`
--

CREATE TABLE IF NOT EXISTS `indicator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(50) NOT NULL,
  `subdomain` varchar(50) NOT NULL,
  `number` varchar(50) CHARACTER SET latin1 NOT NULL,
  `reportingyear` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `link` varchar(200) CHARACTER SET latin1 NOT NULL,
  `title` varchar(500) CHARACTER SET latin1 NOT NULL,
  `numerator` varchar(500) CHARACTER SET latin1 NOT NULL,
  `denominator` varchar(1000) CHARACTER SET latin1 NOT NULL,
  `inclusion` varchar(1000) CHARACTER SET latin1 NOT NULL,
  `exclusion` varchar(500) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `query_variable`
--

CREATE TABLE IF NOT EXISTS `query_variable` (
  `variableid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `indicatorid` int(11) NOT NULL,
  `variable` varchar(200) NOT NULL,
  `table` varchar(200) NOT NULL,
  `isexclusion` tinyint(4) NOT NULL DEFAULT 0,
  `inserted` datetime DEFAULT NULL,
  PRIMARY KEY (`variableid`),
  KEY `userid` (`userid`),
  KEY `indicatorid` (`indicatorid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `selectedall` tinyint(1) NOT NULL,
  `insertedlymphcode` tinyint(1) NOT NULL,
  `definedimlne` tinyint(1) NOT NULL,
  `selectedlne` tinyint(1) NOT NULL,
  `definedimlne2010` tinyint(1) NOT NULL,
  `selectedlne2010` tinyint(1) NOT NULL,
  `unlocked` tinyint(1) NOT NULL,
  `unlock_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
