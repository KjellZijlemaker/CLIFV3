-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 13, 2019 at 11:13 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `patients_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `examination`
--

CREATE TABLE IF NOT EXISTS `examination` (
  `examination_id` int(255) NOT NULL DEFAULT 0,
  `patientid` int(255) DEFAULT NULL,
  `item` text DEFAULT NULL,
  `examination_code` varchar(20) DEFAULT NULL,
  `examination_code_SNOMED` bigint(20) DEFAULT NULL,
  `examination_date` date DEFAULT NULL,
  `results` text DEFAULT NULL,
  `diagnosis1` text DEFAULT NULL,
  `diagnosis2` text DEFAULT NULL,
  `diagnosis3` text DEFAULT NULL,
  `diagnosis4` text DEFAULT NULL,
  `diagnosis5` text DEFAULT NULL,
  `diagnosis6` text DEFAULT NULL,
  PRIMARY KEY (`examination_id`),
  KEY `id_index` (`patientid`),
  KEY `code_index` (`examination_code_SNOMED`),
  KEY `date_index` (`examination_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `firstpage`
--

CREATE TABLE IF NOT EXISTS `firstpage` (
  `patientid` int(11) NOT NULL,
  `admission_diagnosis` text DEFAULT NULL,
  `major_diagnosis` varchar(200) NOT NULL,
  `diagnosis_code_ICD` varchar(20) NOT NULL,
  `diagnosis_code_SNOMED` bigint(20) NOT NULL,
  `diagnosis2` text DEFAULT NULL,
  `code2` varchar(20) DEFAULT NULL,
  `diagnosis3` text DEFAULT NULL,
  `code3` varchar(20) DEFAULT NULL,
  `Allergy_history` text DEFAULT NULL,
  `systolic_pressure` int(11) DEFAULT NULL,
  `diastolic_pressure` int(11) DEFAULT NULL,
  `BMI` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientid`),
  KEY `id_index` (`patientid`),
  KEY `code_index` (`diagnosis_code_SNOMED`),
  KEY `syspr_index` (`systolic_pressure`),
  KEY `BMI_index` (`BMI`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lab_test`
--

CREATE TABLE IF NOT EXISTS `lab_test` (
  `test_number` varchar(255) NOT NULL,
  `patientid` int(11) NOT NULL,
  `item` varchar(255) NOT NULL,
  `test_date` date NOT NULL,
  `test_code` varchar(255) NOT NULL,
  `test_code_SNOMED` bigint(20) DEFAULT NULL,
  `detailed_item` varchar(255) NOT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `result` int(11) DEFAULT NULL,
  `high_level` varchar(255) DEFAULT NULL,
  `low_level` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`test_number`),
  KEY `id_index` (`patientid`),
  KEY `code_index` (`test_code_SNOMED`),
  KEY `result_index` (`result`),
  KEY `date_index` (`test_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `patientid` int(11) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `date_of_birth` date NOT NULL,
  `age` int(11) NOT NULL,
  `admission_date` date DEFAULT NULL,
  `departure_date` date DEFAULT NULL,
  `hosp_days` int(11) DEFAULT NULL,
  `Allergy_history` text DEFAULT NULL,
  PRIMARY KEY (`patientid`),
  KEY `Index_id` (`patientid`),
  KEY `Index_birthday` (`date_of_birth`),
  KEY `Index_adm` (`admission_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE IF NOT EXISTS `treatment` (
  `treatment_date` date NOT NULL,
  `patientid` int(255) NOT NULL,
  `treatment` text NOT NULL,
  `treatment_code_SNOMED` bigint(20) DEFAULT NULL,
  `treatment_type` bigint(20) DEFAULT NULL,
  `dosage` varchar(20) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `frequency` varchar(20) DEFAULT NULL,
  `treatment_status` varchar(10) DEFAULT NULL,
  `conduction_date` date DEFAULT NULL,
  `stop_date` date DEFAULT NULL,
  PRIMARY KEY (`patientid`),
  KEY `code_index` (`treatment_code_SNOMED`),
  KEY `date_index` (`treatment_date`),
  KEY `type_index` (`treatment_type`),
  KEY `id_index` (`patientid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
